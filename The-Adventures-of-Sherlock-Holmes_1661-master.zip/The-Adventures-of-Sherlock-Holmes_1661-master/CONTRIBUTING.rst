=================
How to contribute
=================

The point of GITenberg is to make it easier to access and improve public domain books. 
We _love_ to get contributions, and there are a number of ways you can get involved, no matter what your skillset.

If you would like to help, vist the contributing_ section of our website for more information.

.. _contributing: http://gitenberg.github.io/#contributing
